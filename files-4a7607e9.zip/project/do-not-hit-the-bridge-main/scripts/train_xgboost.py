"""
Train multiple XGBoost models on data/processed/features.csv:

1. Nowcast residual (measured_gauge_height_ft - tide_ft) at time t
   → fills measurement gaps / display lag.

2. Multi-horizon residual regression for lead times
   1 h, 3 h, 6 h, 12 h, 24 h, 36 h.

3. Binary classification of threshold crossovers at 1.86 ft:
   - rising  (level crosses upward through 1.86 ft within the horizon)
   - falling (level crosses downward through 1.86 ft within the horizon)
   for each of the same horizons.

All models share the same feature pipeline and time-based split.
Models + metadata are written under data/processed/model/.
"""
from __future__ import annotations

from pathlib import Path
import json
from datetime import datetime, timezone
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)

from config import DATA_PROCESSED

FEATURES_PATH = DATA_PROCESSED / "features.csv"
MODEL_DIR = DATA_PROCESSED / "model"

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
HORIZONS_H = [1, 3, 6, 12, 24, 36]
CROSSOVER_THRESH_FT = 1.86

EXCLUDE = {
    "measured_gauge_height_ft",
    "measured_water_level",
    "measured_Water Level",
    "measured_depth",
    "measured_value",
    "phase_name",
    "short_forecast",
    "wind_direction",
    "station",
    # targets we create (will also be dropped dynamically)
    "tide_residual",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def prepare_xy(
    df: pd.DataFrame,
    target: str,
    extra_drop: List[str] | None = None,
) -> Tuple[pd.DataFrame, pd.Series, List[str]]:
    """Return X, y and the ordered list of feature names."""
    numeric = df.select_dtypes(include=[np.number]).copy()

    drop = set(EXCLUDE)
    if extra_drop:
        drop.update(extra_drop)
    drop.add(target)

    # Also drop every other target column so they never leak into features
    target_like = [
        c
        for c in numeric.columns
        if c.startswith(("residual_", "cross_rising_", "cross_falling_"))
        or c == "tide_residual"
    ]
    drop.update(target_like)

    feature_cols = [c for c in numeric.columns if c not in drop]
    X = numeric[feature_cols].copy()
    y = numeric[target].copy()

    mask = y.notna()
    X = X.loc[mask]
    y = y.loc[mask]

    # Impute sparse external features
    X = X.ffill().bfill()
    for col in X.columns:
        if X[col].isna().any():
            if "rain" in col.lower():
                X[col] = X[col].fillna(0.0)
            else:
                med = X[col].median()
                X[col] = X[col].fillna(med if pd.notna(med) else 0.0)

    still_bad = X.isna().any(axis=1) | y.isna()
    if still_bad.any():
        X = X.loc[~still_bad]
        y = y.loc[~still_bad]

    return X, y, feature_cols


def _infer_freq(index: pd.DatetimeIndex) -> pd.Timedelta:
    """Best-effort median sampling interval."""
    if len(index) < 2:
        return pd.Timedelta(minutes=15)
    diffs = index.to_series().diff().dropna()
    # drop extreme outliers (gaps)
    q = diffs.quantile(0.9)
    diffs = diffs[diffs <= q]
    med = diffs.median()
    if pd.isna(med) or med <= pd.Timedelta(0):
        return pd.Timedelta(minutes=15)
    return med


def _steps_for_horizon(freq: pd.Timedelta, hours: int) -> int:
    steps = max(1, int(round(pd.Timedelta(hours=hours) / freq)))
    return steps


def build_crossover_labels(
    level: pd.Series,
    thresh: float,
    steps: int,
) -> Tuple[pd.Series, pd.Series]:
    """
    Binary labels for a rising / falling crossover of `thresh` inside the
    next `steps` observations.

    Rising  : there exists a point in (t, t+steps] where level >= thresh
              and the previous point was < thresh.
    Falling : there exists a point in (t, t+steps] where level <= thresh
              and the previous point was > thresh.
    """
    n = len(level)
    rising = np.zeros(n, dtype=np.float64)
    falling = np.zeros(n, dtype=np.float64)

    vals = level.to_numpy(dtype=float)
    # vectorised-ish loop (data sets are modest for tide gauges)
    for i in range(n - 1):
        end = min(i + steps + 1, n)
        window = vals[i:end]
        if len(window) < 2:
            rising[i] = np.nan
            falling[i] = np.nan
            continue

        # Rising crossings inside the future window
        below = window[:-1] < thresh
        above_or_eq = window[1:] >= thresh
        rising[i] = 1.0 if np.any(below & above_or_eq) else 0.0

        # Falling crossings
        above = window[:-1] > thresh
        below_or_eq = window[1:] <= thresh
        falling[i] = 1.0 if np.any(above & below_or_eq) else 0.0

    # last `steps` rows have incomplete future → NaN
    rising[-steps:] = np.nan
    falling[-steps:] = np.nan

    idx = level.index
    return (
        pd.Series(rising, index=idx, name="cross_rising"),
        pd.Series(falling, index=idx, name="cross_falling"),
    )


def time_split(
    X: pd.DataFrame,
    y: pd.Series,
    test_days: int,
) -> Tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series]:
    cutoff = X.index.max() - pd.Timedelta(days=test_days)
    train_mask = X.index < cutoff
    test_mask = X.index >= cutoff

    X_train, y_train = X.loc[train_mask], y.loc[train_mask]
    X_test, y_test = X.loc[test_mask], y.loc[test_mask]

    if len(X_test) < 5 or len(X_train) < 20:
        split = int(len(X) * 0.8)
        X_train, y_train = X.iloc[:split], y.iloc[:split]
        X_test, y_test = X.iloc[split:], y.iloc[split:]
        print("  Short history – using 80/20 sequential split")

    return X_train, y_train, X_test, y_test


def train_regressor(
    X_train, y_train, X_test, y_test, feature_cols, params: dict
) -> Tuple[xgb.XGBRegressor, dict]:
    model = xgb.XGBRegressor(
        n_estimators=params["n_estimators"],
        max_depth=params["max_depth"],
        learning_rate=params["learning_rate"],
        subsample=0.8,
        colsample_bytree=0.8,
        objective="reg:squarederror",
        n_jobs=-1,
        random_state=42,
    )
    model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)

    pred = model.predict(X_test)
    mae = float(mean_absolute_error(y_test, pred))
    rmse = float(np.sqrt(mean_squared_error(y_test, pred)))

    metrics = {
        "mae": mae,
        "rmse": rmse,
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
    }
    return model, metrics


def train_classifier(
    X_train, y_train, X_test, y_test, feature_cols, params: dict
) -> Tuple[xgb.XGBClassifier, dict]:
    # Handle severe class imbalance
    pos = float((y_train == 1).sum())
    neg = float((y_train == 0).sum())
    scale = neg / pos if pos > 0 else 1.0

    model = xgb.XGBClassifier(
        n_estimators=params["n_estimators"],
        max_depth=params["max_depth"],
        learning_rate=params["learning_rate"],
        subsample=0.8,
        colsample_bytree=0.8,
        objective="binary:logistic",
        scale_pos_weight=scale,
        n_jobs=-1,
        random_state=42,
        eval_metric="logloss",
    )
    model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)

    pred = model.predict(X_test)
    proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision": float(precision_score(y_test, pred, zero_division=0)),
        "recall": float(recall_score(y_test, pred, zero_division=0)),
        "f1": float(f1_score(y_test, pred, zero_division=0)),
        "auc": float(roc_auc_score(y_test, proba)) if y_test.nunique() > 1 else 0.0,
        "n_train": int(len(X_train)),
        "n_test": int(len(X_test)),
        "pos_rate_train": float(pos / (pos + neg)) if (pos + neg) > 0 else 0.0,
        "scale_pos_weight": scale,
    }
    return model, metrics


def save_model(
    model,
    name: str,
    feature_cols: List[str],
    metrics: dict,
    task: str,
    extra_meta: dict | None = None,
):
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model_path = MODEL_DIR / f"xgb_{name}.json"
    meta_path = MODEL_DIR / f"meta_{name}.json"

    model.save_model(model_path)

    meta = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "name": name,
        "task": task,  # "nowcast" | "horizon_residual" | "crossover_rising" | "crossover_falling"
        "feature_cols": feature_cols,
        "metrics": metrics,
        **(extra_meta or {}),
    }
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)

    print(f"  → saved {model_path.name}  |  {meta_path.name}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(
    test_days: int = 2,
    n_estimators: int = 400,
    max_depth: int = 6,
    learning_rate: float = 0.05,
):
    if not FEATURES_PATH.exists():
        raise FileNotFoundError(
            f"{FEATURES_PATH} not found – run build_features.py first"
        )

    print("Loading features…")
    df = pd.read_csv(FEATURES_PATH, index_col=0, parse_dates=True)
    if df.index.tz is None:
        df.index = pd.to_datetime(df.index, utc=True)
    df = df.sort_index()

    if "tide_ft" not in df.columns:
        raise ValueError("tide_ft missing – cannot train residual model")
    if "measured_gauge_height_ft" not in df.columns:
        raise ValueError("measured_gauge_height_ft missing")

    # Base residual
    df["tide_residual"] = df["measured_gauge_height_ft"] - df["tide_ft"]
    df = df.dropna(subset=["tide_residual", "tide_ft", "measured_gauge_height_ft"])

    freq = _infer_freq(df.index)
    print(f"Inferred median sampling interval: {freq}")

    # ------------------------------------------------------------------
    # 1. Build all target columns
    # ------------------------------------------------------------------
    # Nowcast already exists as tide_residual

    # Multi-horizon residual
    for h in HORIZONS_H:
        steps = _steps_for_horizon(freq, h)
        col = f"residual_{h}h"
        df[col] = df["tide_residual"].shift(-steps)
        # last `steps` rows become NaN automatically

    # Crossover labels (rising & falling) per horizon
    level = df["measured_gauge_height_ft"]
    for h in HORIZONS_H:
        steps = _steps_for_horizon(freq, h)
        rising, falling = build_crossover_labels(level, CROSSOVER_THRESH_FT, steps)
        df[f"cross_rising_{h}h"] = rising
        df[f"cross_falling_{h}h"] = falling

    # ------------------------------------------------------------------
    # 2. Train nowcast residual
    # ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("NOWCAST residual")
    print("=" * 60)

    X, y, feature_cols = prepare_xy(df, "tide_residual")
    print(f"Usable rows: {len(X)}  |  features: {len(feature_cols)}")

    if len(X) < 48:
        raise SystemExit(f"Not enough usable rows ({len(X)} < 48)")

    X_train, y_train, X_test, y_test = time_split(X, y, test_days)
    print(f"Train: {len(X_train)}  |  Test: {len(X_test)}")

    params = {
        "n_estimators": n_estimators,
        "max_depth": max_depth,
        "learning_rate": learning_rate,
    }
    model, metrics = train_regressor(
        X_train, y_train, X_test, y_test, feature_cols, params
    )
    print(f"  MAE  : {metrics['mae']:.4f} ft")
    print(f"  RMSE : {metrics['rmse']:.4f} ft")

    importance = (
        pd.Series(model.feature_importances_, index=feature_cols)
        .sort_values(ascending=False)
        .head(10)
    )
    print("  Top features:\n", importance.to_string())

    save_model(
        model,
        "nowcast",
        feature_cols,
        metrics,
        task="nowcast",
        extra_meta={"xgb_params": params, "test_days": test_days, "target": "tide_residual"},
    )

    # Legacy filenames so older generate_forecast.py still works during transition
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model.save_model(MODEL_DIR / "xgb_model.json")
    legacy_meta = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "target": "tide_residual",
        "feature_cols": feature_cols,
        "n_train": metrics["n_train"],
        "n_test": metrics["n_test"],
        "mae": metrics["mae"],
        "rmse": metrics["rmse"],
        "test_days": test_days,
        "xgb_params": params,
        "note": "Legacy single-model file; prefer xgb_nowcast.json + multi-horizon models",
    }
    with open(MODEL_DIR / "model_meta.json", "w") as f:
        json.dump(legacy_meta, f, indent=2)
    print("  → also wrote legacy xgb_model.json + model_meta.json")

    # ------------------------------------------------------------------
    # 3. Multi-horizon residual regression
    # ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("MULTI-HORIZON residual regression")
    print("=" * 60)

    for h in HORIZONS_H:
        target = f"residual_{h}h"
        print(f"\n--- Horizon {h} h ---")
        X, y, feature_cols = prepare_xy(df, target)
        print(f"Usable rows: {len(X)}")

        if len(X) < 48:
            print("  Skipping – too few rows")
            continue

        X_train, y_train, X_test, y_test = time_split(X, y, test_days)
        print(f"Train: {len(X_train)}  |  Test: {len(X_test)}")

        model, metrics = train_regressor(
            X_train, y_train, X_test, y_test, feature_cols, params
        )
        print(f"  MAE  : {metrics['mae']:.4f} ft")
        print(f"  RMSE : {metrics['rmse']:.4f} ft")

        save_model(
            model,
            f"residual_{h}h",
            feature_cols,
            metrics,
            task="horizon_residual",
            extra_meta={
                "horizon_hours": h,
                "xgb_params": params,
                "test_days": test_days,
            },
        )

    # ------------------------------------------------------------------
    # 4. Binary crossover classifiers (rising & falling)
    # ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print(f"CROSSOVER classifiers @ {CROSSOVER_THRESH_FT} ft")
    print("=" * 60)

    for h in HORIZONS_H:
        for direction, prefix in [("rising", "cross_rising"), ("falling", "cross_falling")]:
            target = f"{prefix}_{h}h"
            print(f"\n--- {direction.upper()} crossover, horizon {h} h ---")

            X, y, feature_cols = prepare_xy(df, target)
            print(f"Usable rows: {len(X)}  |  positive rate: {y.mean():.3f}")

            if len(X) < 48 or y.nunique() < 2:
                print("  Skipping – too few rows or only one class")
                continue

            X_train, y_train, X_test, y_test = time_split(X, y, test_days)
            print(f"Train: {len(X_train)}  |  Test: {len(X_test)}")

            model, metrics = train_classifier(
                X_train, y_train, X_test, y_test, feature_cols, params
            )
            print(
                f"  Acc={metrics['accuracy']:.3f}  "
                f"P={metrics['precision']:.3f}  "
                f"R={metrics['recall']:.3f}  "
                f"F1={metrics['f1']:.3f}  "
                f"AUC={metrics['auc']:.3f}"
            )

            save_model(
                model,
                f"{prefix}_{h}h",
                feature_cols,
                metrics,
                task=f"crossover_{direction}",
                extra_meta={
                    "horizon_hours": h,
                    "threshold_ft": CROSSOVER_THRESH_FT,
                    "direction": direction,
                    "xgb_params": params,
                    "test_days": test_days,
                },
            )

    # ------------------------------------------------------------------
    # Summary index of all models
    # ------------------------------------------------------------------
    summary = {
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "horizons_h": HORIZONS_H,
        "crossover_threshold_ft": CROSSOVER_THRESH_FT,
        "models": sorted(p.stem for p in MODEL_DIR.glob("xgb_*.json")),
    }
    with open(MODEL_DIR / "models_index.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("\n" + "=" * 60)
    print("All models written to", MODEL_DIR)
    print("Index →", MODEL_DIR / "models_index.json")
    print("=" * 60)


if __name__ == "__main__":
    main()
